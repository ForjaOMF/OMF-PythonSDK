# -*- coding: cp1252 -*-
# SMSSender sample code
#

import httplib, urllib

import SMSSenderAPI

login = '6xxxxxxxx'
pwd = 'xxxxxx'

dest = '6xxxxxxxx'

msg = 'message'

sender = SMSSenderAPI.SMSSender()
sender.SendMessage(login, pwd, dest, msg)
